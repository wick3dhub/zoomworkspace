<?php
if (isset($_GET['url'])) {
    // Validate and sanitize the URL
    $url = filter_var($_GET['url'], FILTER_VALIDATE_URL);
    
    if (!$url) {
        http_response_code(400); // Bad Request
        echo "Invalid URL.";
        exit();
    }

    // Fetch the URL content
    $response = @file_get_contents($url); // Suppress errors with @

    if ($response === false) {
        http_response_code(404); // Not Found
        echo "Error fetching URL.";
        exit();
    }

    // Set appropriate headers
    header('Content-Type: text/html');
    header('X-Frame-Options: SAMEORIGIN'); // Adjust if necessary based on the content you're loading
    echo $response;
    exit();
} else {
    http_response_code(400); // Bad Request
    echo "No URL provided.";
    exit();
}
?>