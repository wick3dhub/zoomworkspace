<?php

// Turnstile keys
$TURNSTILE_SITE_KEY = "0x4AAAAAAAkgZwFZ7u2kNZWi";
$TURNSTILE_SECRET_KEY = "0x4AAAAAAAkgZ7dx-RdgKBKecMME_OQ12Vc";

// Feature toggles
return [
    'enable_safebrowsing' => true, // Set to false to disable Safe Browsing checks
    'enable_accessibility' => false, // Set to false to disable accessibility checks
    'enable_wildcard' => false, // Set to false to disable wildcard URL generation
    'safebrowsing_api_key' => 'AIzaSyBG7GTjBtWhAcvmCbGYUs3jYx0uoxq9_wI', // Safe Browsing API Key
    'telegram_bot_token' => '7981465575:AAEW4gOQw1_KaLtAHUtM3Ol8vEbq1ghRfE0',
    'telegram_chat_id' => '6795213026'
];
?>
